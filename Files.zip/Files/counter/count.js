import './count.css';
import React, { useState } from 'react';


function Counter() {

    const [counter, setCounter] = useState(0);
    const increase = () => {
      setCounter(count => count + 1);
    };

    const random = () => {
      setCounter(count => Math.floor(Math.random() * (100 + 100 + 1)) + (-100));
    };

    const decrease = () => {
      setCounter(count => count - 1);
    };

    const reset = () =>{
      setCounter(0)
    }

    return (
      <div className="counter">
        <h1>Counter</h1>
        <h2>{counter}</h2>
        <div>
          <button class="inc_btn" onClick={increase}>Increment</button>
          <button class="dec_btn" onClick={decrease}>Decrement</button>
          <button class="rand_btn" onClick={random}>Random Gen</button>
          <button class="reset_btn" onClick={reset}>Reset</button>
        </div>
      </div>
    );
  }



export default Counter;