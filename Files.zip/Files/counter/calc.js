import React, { useState } from 'react';
import './count.css';


const Calculator = () => {
  const [principal, setPrincipal] = useState(0);
  const [rate, setRate] = useState(0);
  const [year, setYear] = useState(0);
  const [amount, setAmount] = useState(0);

  const resetValues = () => {
    setPrincipal(0);
    setRate(0);
    setYear(0);
    setAmount(0);
  }
  const calculateSimpleInterest = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate) / 100;
    const t = parseFloat(year);
    setAmount((p * r * t / 100)*100);
  }
  const calculateCompoundInterest = () => {
    const p = parseFloat(principal);
    const r = parseFloat(rate) / 100;
    const t = parseFloat(year);
    setAmount(p * Math.pow(1 + (r / 100), t));
  }
  return (
    <div className="counter">
            <h2>Amount {amount}</h2>
      <h1><label>Principal Amount</label><br /><input value={principal} onChange={(e) => setPrincipal(e.target.value)}></input><br /></h1>
      <h1><label>Rate of Interest (p.a)</label><br /><input value={rate} onChange={(e) => setRate(e.target.value)}></input><br /></h1>
      <h1><label>Time Period(Yr)</label><br /><input value={year} onChange={(e) => setYear(e.target.value)}></input><br /></h1>
      <button class ='rand_btn' type="submit" onClick={calculateSimpleInterest}>Calculate Simple Interest</button>
      <button class ='rand_btn' type="submit" onClick={calculateCompoundInterest}>Calculate Compound Interest</button>
      <button class ='rand_btn' type="submit" onClick={resetValues}>Reset</button><br />

    </div>
  )
}

export default Calculator;