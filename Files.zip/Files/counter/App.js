import React, { Component } from 'react'; 
import { BrowserRouter as Router,Routes, Route, Link } from 'react-router-dom'; 
import Home from './home';
import Calculator from './calc';
import Counter from './count';
import Quad from './quad';
import './appy.css'; 

class App extends Component { 
render() { 
	return ( 
	<Router> 
		<div id="div_top_hypers">
      <ul id="ul_top_hypers">
			<li> 
				<Link to="/">Home</Link> 
			</li> 
			<li> 
				<Link to="/Counter">Counter</Link> 
			</li> 
			<li> 
				<Link to="/Calculator">Calculator</Link> 
			</li> 
      <li>
      <Link to="/Quad">Quadratic Solver</Link> 
      </li>
			</ul> 
		<Routes> 
				<Route exact path='/' element={< Home />}></Route> 
				<Route exact path='/Counter' element={< Counter/>}></Route> 
				<Route exact path='/Calculator' element={< Calculator />}></Route> 
        <Route exact path='/Quad' element={< Quad />}></Route> 
		</Routes> 
		</div> 
	</Router> 
); 
} 
} 

export default App;
