const Username = ({ username, onChange }) => {
  return (
    <input type="text" name="username" placeholder="Username" value={username} onChange={onChange} />
  );
};

export default Username;
