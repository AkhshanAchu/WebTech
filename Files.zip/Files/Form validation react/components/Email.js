const Email = ({ username, onChange }) => {
    return (
      <input type="text" name="email" placeholder="Email" />
    );
  };
  
  export default Email;