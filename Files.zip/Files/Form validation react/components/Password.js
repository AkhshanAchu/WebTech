const Password = ({ password, onChange }) => {
  return (
    <input type="password" name="password" placeholder="Password" value={password} onChange={onChange} />
  );
};

export default Password;
