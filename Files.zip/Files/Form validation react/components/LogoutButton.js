const LogoutButton = ({ onClick }) => {
    return (
        <button type="button" onClick={onClick}>Logout</button>
    );
};

export default LogoutButton;
