const LoginButton = () => {
    return (
        <button type="submit">Login</button>
    );
};

export default LoginButton;
