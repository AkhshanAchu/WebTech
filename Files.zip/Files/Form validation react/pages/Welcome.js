import LogoutButton from "../components/LogoutButton";

const Welcome = ({ onLogout }) => {
  return (
    <div>
      <h1>Welcome to the webpage. Please click on the logout button</h1>
      <LogoutButton onClick={onLogout} />
    </div>
  );
};

export default Welcome;
