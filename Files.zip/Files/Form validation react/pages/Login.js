import { useState } from "react";
import Username from "../components/Username";
import Password from "../components/Password";
import Email from "../components/Email";
import LoginButton from "../components/LoginButton";

const LoginForm = ({ onLogin }) => {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = () => {
    if (!/^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9]).*$/.test(password)) {
      return alert("Password must contain at least 1 lowercase, 1 uppercase, and 1 number.");
    }

    const users = [
      { username: "admin", password: "Password1!" },
      { username: "Abhiroop", password: "Abhi@roop4" },
    ];

    const user = users.find((user) => user.username === username && user.password === password);
    if (user) {
      onLogin();
    } else {
      alert("Invalid username or password.");
    }
  };

  return (
    <div class="login">
      <hi>Login</hi>
      <br></br><br></br>
      <form onSubmit={handleSubmit}>
        <Username username={username} onChange={(e) => setUsername(e.target.value)} />
        <br></br>
        <Email />
        <br></br>
        <Password password={password} onChange={(e) => setPassword(e.target.value)} />
        <br></br>
        <LoginButton />
      </form>
    </div>
  );
};

export default LoginForm;
