import React, { useState } from 'react';
import './App.css';

const employees = [
  { name: "Tony Stark", department: "IT" },
  { name: "Peter Parker", department: "Pizza Delivery" },
  { name: "Bruce Wayne", department: "IT" },
  { name: "Clark Kent", department: "Editing" }
];

function App() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selecteddepartment, setSelecteddepartment] = useState('All');

  const handledepartmentChange = (event) => {
    setSelecteddepartment(event.target.value);
  };

  const filteredemployees = employees.filter((employee) => {
    if (selecteddepartment === 'All') {
      return employee.name.toLowerCase().includes(searchTerm.toLowerCase());
    } else {
      return (
        employee.department === selecteddepartment &&
        employee.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
  });

  return (
    <div className="App">
      <h1>Filter Page</h1>
      <div className="filters">
        <select value={selecteddepartment} onChange={handledepartmentChange}>
          <option value="All">All</option>
          <option value="IT">IT</option>
          <option value="Pizza Delivery">Pizza Delivery</option>
          <option value="Editing">Editing</option>
        </select>
      </div>
      <div className="employee-list">
          <div>
            <table align='center'>
                <tr>
                  <th>Name</th>
                  <th>department</th>
                </tr>
                {filteredemployees.map((employee) => (
                 <tr>
                  <td><span>{employee.name}</span></td>
                  <td><span> {employee.department}</span></td>
                </tr>
                ))}
              </table>
          </div>
       
      </div>
    </div>
  );
}

export default App;
