import React, { useState } from 'react';
import './count.css';




const Quad = () => {
  const [a, seta] = useState(0);
  const [b, setb] = useState(0);
  const [c, setc] = useState(0);
  const [roota, setroota] = useState(0);
  const [rootb, setrootb] = useState(0);

  function Displayer(props) {
    return <h2>{props.name}</h2>;
  }
  const resetValues = () => {
    seta(0);
    setb(0);
    setc(0);
    setroota(0);
    setrootb(0);
  }
  const quad = () => {
    const p = parseFloat(a);
    const r = parseFloat(b);
    const t = parseFloat(c);
    const d = (r*r)-(4*p*t);

    if(d<0){
        setroota("Imaginary");
        setrootb("Imaginary");
    }
    if(d==0){
        setroota((-r)/(2*p));
        setrootb((-r)/(2*p));
    }
    else{
        setroota(((-r)-Math.sqrt(d))/(2*p));
        setrootb(((-r)+Math.sqrt(d))/(2*p));
    }
  }
  return (
    <div className="counter">
        <Displayer name="Quadratic Root"></Displayer>
        <h2>{roota} , {rootb}</h2>
      <h1><label>Coefficient of X^2</label><br /><input value={a} onChange={(e) => seta(e.target.value)}></input><br /></h1>
      <h1><label>Coefficient of X</label><br /><input value={b} onChange={(e) => setb(e.target.value)}></input><br /></h1>
      <h1><label>Constant</label><br /><input value={c} onChange={(e) => setc(e.target.value)}></input><br /></h1>
      <button class ='rand_btn' type="submit" onClick={quad}>Solve</button>
      <button class ='rand_btn' type="submit" onClick={resetValues}>Reset</button><br />
    </div>
  )
}

export default Quad;