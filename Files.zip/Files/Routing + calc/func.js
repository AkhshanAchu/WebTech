
const quad = () => {
    const p = parseFloat(a);
    const r = parseFloat(b);
    const t = parseFloat(c);
    const d = (r*r)-(4*p*t);

    if(d<0){
        setroota("Imaginary");
        setrootb("Imaginary");
    }
    if(d==0){
        setroota((-r)/(2*p));
        setrootb((-r)/(2*p));
    }
    else{
        setroota(((-r)-Math.sqrt(d))/(2*p));
        setrootb(((-r)+Math.sqrt(d))/(2*p));
    }
  }

  export default quad;