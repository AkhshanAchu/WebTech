changeMode('light');
function changeMode( mode ){
	if (mode == "dark"){
		var allLinks = document.head.getElementsByTagName('link');

        for (var i = 0; i < allLinks.length; i++) {
            if ( allLinks[i].href = "test.css") {
                allLinks[i].href = "dark.css";
            }
        }
	}
	else if(mode == "light"){
		var allLinks = document.head.getElementsByTagName('link');

        for (var i = 0; i < allLinks.length; i++) {
            if ( allLinks[i].href = "test.css") {
                allLinks[i].href = "test.css";
            }
        }
	}
	else if(mode == "default"){
		var allLinks = document.head.getElementsByTagName('link');

        for (var i = 0; i < allLinks.length; i++) {
            if ( allLinks[i].href = "test.css") {
                allLinks[i].href = "fun.css";
            }
        }
	}
	console.log(mode);
}