import image from '../images/HOME.png'

export default function Home(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}