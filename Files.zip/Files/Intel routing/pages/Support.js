import image from '../images/SUPPORT.png'

export default function Support(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}