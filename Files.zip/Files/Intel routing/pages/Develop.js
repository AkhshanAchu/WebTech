import image from '../images/DEVELOP.png'

export default function Develop(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}