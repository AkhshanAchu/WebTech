import image from '../images/DEVELOP.png'

export default function Contact(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}