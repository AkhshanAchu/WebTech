import image from '../images/SOLUTIONS.png'

export default function Solution(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}