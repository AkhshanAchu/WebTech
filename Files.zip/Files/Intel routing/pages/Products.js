import image from '../images/PRODUCT.png'

export default function Products(){
    return(
        <img src={image} style={{width:'100%'}} alt="NOT FOUND"></img>
    );
}