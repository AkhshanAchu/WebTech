import './App.css';
import { BrowserRouter as Router , Link, Routes, Route } from "react-router-dom";

// All page imports
import Home from "./pages/Home.js";
import Products from "./pages/Products.js";
import Support from "./pages/Support.js";
import Solution from "./pages/Solution.js";
import Contact from "./pages/Contact.js";
import Develop from "./pages/Develop.js";


//The Elements and Dim elements in the nav bar are given as array
const Elements = ["PRODUCTS","SUPPORT", "SOLUTIONS", "DEVELOPERS", "PARTNERS"];


export function NavBar({ Elements }) {
  return (
    <div className="header">
      <table>
        <th bgcolor="darkblue" text-align ="center" class="log"><ul><Link to='/'><img src="https://www.intel.com/content/dam/logos/intel-header-logo.svg" alt="Logo" class="logo"/></Link></ul></th>
        <th> <ul> {Elements.map((element) => (
          <li><Link to={"/"+element}>{element}</Link></li>
        ))}</ul></th>
      </table>
    </div>
  );
}

// App contains Nav-Bar and routes to all the pages
export default function App() {
  return (
    <Router>
      <NavBar Elements={Elements} />
      <Routes>
        <Route path="/" element=< Home/> />
        <Route path="/Products" element=< Products/> />
        <Route path="/Support" element=< Support/>/>
        <Route path="/Solutions" element=< Solution/> />
        <Route path="/Contact" element=< Contact/> />
        <Route path="/Developers" element=< Develop/> />
      </Routes>
    </Router>
  );
}